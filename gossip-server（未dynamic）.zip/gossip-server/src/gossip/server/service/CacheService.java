package gossip.server.service;

import com.google.gson.Gson;

public class CacheService {
	
	public static void main(String[] args){
		Gson gson = new Gson();
	}

}
