package gossip.server.action;

import gossip.server.service.EventService;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 访问事件的action。
 * 
 * @author lins
 */
@Controller
@RequestMapping("/events")
public class EventAction {
	@Autowired
	EventService eventService;
	
	@RequestMapping(value = "")
	@ResponseBody
	public JSONObject getEventList(
			@RequestParam(value = "pageNo", required = false, defaultValue = "0") int pageNo,
			@RequestParam(value = "limit", required = false, defaultValue = "10") int limit,
			@RequestParam(value = "year", required = false, defaultValue = "0") int year,
			@RequestParam(value = "month", required = false, defaultValue = "1") int month,
			@RequestParam(value = "day", required = false, defaultValue = "1") int day) {
		return eventService.getEventList(pageNo, limit, year, month, day);
	}
	
}
