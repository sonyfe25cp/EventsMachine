package gossip.server.mapper;

public interface ClickLogMapper {

}
