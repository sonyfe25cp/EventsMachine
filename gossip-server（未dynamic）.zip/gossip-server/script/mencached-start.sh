#! /bin/bash
cd /home/lins/bin/memcached/bin
./memcached  -d -m 10 -p 11211 -u root
